﻿#include "stdafx.h"
#include "ntdll.hpp"

using std::string;
using std::exception;
using logger::logf;
using std::vector;
using std::wstring;
#define null NULL

#undef Module32First;
#undef Module32Next
#undef MODULEENTRY32
#undef Process32First
#undef Process32Next
#undef PROCESSENTRY32

#define STATUS_INFO_LENGTH_MISMATCH 0xC0000004
#define SystemHandleInformation 16

BOOL WINAPI DllMain(HMODULE hm, DWORD ulCallReason, void*);
typedef NTSTATUS(NTAPI* NtQuerySystemInformationFn)(ULONG, PVOID, ULONG, PULONG);

typedef struct _SYSTEM_HANDLE
{
	ULONG ProcessId;
	BYTE ObjectTypeNumber;
	BYTE Flags;
	USHORT Handle;
	PVOID Object;
	ACCESS_MASK GrantedAccess;
} SYSTEM_HANDLE, *PSYSTEM_HANDLE;

typedef struct _SYSTEM_HANDLE_INFORMATION
{
	ULONG HandleCount;
	SYSTEM_HANDLE Handles[1];
} SYSTEM_HANDLE_INFORMATION, *PSYSTEM_HANDLE_INFORMATION;

// implementation 1, works well enough

HANDLE GetProcessHandle(uint64_t targetProcessId)
{
	auto NtQuerySystemInformation = reinterpret_cast<NtQuerySystemInformationFn>(GetProcAddress(GetModuleHandleA(E("ntdll.dll")), E("NtQuerySystemInformation")));
	NTSTATUS status;
	ULONG handleInfoSize = 0x10000;

	auto handleInfo = reinterpret_cast<PSYSTEM_HANDLE_INFORMATION>(malloc(handleInfoSize));

	while ((status = NtQuerySystemInformation(SystemHandleInformation, handleInfo, handleInfoSize, nullptr)) == STATUS_INFO_LENGTH_MISMATCH)
		handleInfo = reinterpret_cast<PSYSTEM_HANDLE_INFORMATION>(realloc(handleInfo, handleInfoSize *= 2));

	if (!NT_SUCCESS(status))
	{
		throw std::exception(E("NtQu3rySystemEnformation feiled!"));
	}

	for (auto i = 0; i < handleInfo->HandleCount; i++)
	{
		auto handle = handleInfo->Handles[i];

		const auto process = reinterpret_cast<HANDLE>(handle.Handle);
		if (handle.ProcessId == GetCurrentProcessId() && GetProcessId(process) == targetProcessId)
			return process;
	}

	free(handleInfo);

	return nullptr;
}

ACCESS_MASK QueryHandleAccessMask(HANDLE handle)
{
	typedef NTSTATUS(*NtQueryObjectFn)(
		_In_opt_  HANDLE                   Handle,
		_In_      OBJECT_INFORMATION_CLASS ObjectInformationClass,
		_Out_opt_ PVOID                    ObjectInformation,
		_In_      ULONG                    ObjectInformationLength,
		_Out_opt_ PULONG                   ReturnLength
		);

	auto NtQueryObject = (NtQueryObjectFn)GetProcAddress(GetModuleHandleA(E("ntdll.dll")), E("NtQueryObject"));
	if (!NtQueryObject) throw exception(E("Couldn't get address of NtQueryObject"));

	PUBLIC_OBJECT_BASIC_INFORMATION objInfo;
	if (!NT_SUCCESS(NtQueryObject(handle, ObjectBasicInformation, &objInfo, sizeof(objInfo), null))) throw exception(E("NtQ33ryObject feiled"));
	return objInfo.GrantedAccess;
}

#define A(s) ToA(s)
#define W(s) ToW(s)
#define LC(s) ToLower(s)

static wstring ToW(string str)
{
	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
	return converter.from_bytes(str);
}

static string ToA(wstring wstr)
{
	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
	return converter.to_bytes(wstr);
}

static string ToLower(string str)
{
	transform(str.begin(), str.end(), str.begin(), tolower);
	return str;
}

static wstring ToLower(wstring str)
{
	transform(str.begin(), str.end(), str.begin(), tolower);
	return str;
}

vector<uint64_t> GetProcessIdsByName(string name)
{
	vector<uint64_t> res;
	HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, null);
	if (!snap) throw exception(E("CreateToolhelp32Snapshot failed"));
	PROCESSENTRY32 entry;
	entry.dwSize = sizeof(entry);
	if (!Process32First(snap, &entry)) throw exception(E("Process32First f3iled"));
	do
	{
		if (LC(entry.szExeFile) == LC(name))
		{
			res.push_back(entry.th32ProcessID);
		}
	} while (Process32Next(snap, &entry));
	CloseHandle(snap);
	return res;
}

std::vector<std::string> SplitString(const std::string& s, char delimiter)
{
	std::vector<std::string> tokens;
	std::string token;
	std::istringstream tokenStream(s);
	while (std::getline(tokenStream, token, delimiter))
	{
		if(token.length())
			token.pop_back(); // because fuck you :^)
		tokens.push_back(token);
	}
	return tokens;
}

void ResetFile(string path)
{
	HANDLE dummy = CreateFileA(path.c_str(), GENERIC_WRITE, null, null, CREATE_ALWAYS, null, null);
	CloseHandle(dummy);
}

bool ReadRequest(string ipcfile, vector<string>& lines)
{
	auto contents = binary_file::read_file(ipcfile);
	if (!contents.size()) return false;
	string s;
	s.resize(contents.size() + 1);
	memcpy(s.data(), contents.data(), contents.size());
	s[contents.size()] = '\0';
	lines = SplitString(s, '\n');
	ResetFile(ipcfile);
	return lines.size() == 10 || lines.size() == 11 || (lines.size() == 1 && lines[0] == E("ABORT LMFAO"));
}

vector<string> AwaitRequest(string ipcfile, DWORD delay)
{
	vector<string> lines;
	while (!ReadRequest(ipcfile, lines))
	{
		Sleep(delay);
	}
	return lines;
}

string AppData()
{
	char buff[MAX_PATH];
	auto hr = SHGetFolderPathA(null, CSIDL_APPDATA, null, null, buff);
	if (FAILED(hr))
	{
		return "C:"; // easy fix
	}
	return buff;
}

bool HandleHasAccess(HANDLE handle, ACCESS_MASK mask)
{
	return (QueryHandleAccessMask(handle) & mask) == mask;
}

DWORD main(void*)
{
	atexit([]() {
		DllMain(0x0, DLL_PROCESS_DETACH, 0x0);
	});

	string logfile = AppData() + E("\\ntmapper-log.txt");
	string ipcfile = AppData() + E("\\ntmapper-control.txt");

	ResetFile(ipcfile);

	logger::initialize(logfile , E("[+] "), "");
	ntdll::initialise();

	bool open_process;
	bool create_thread;
	bool wait_10s;
	module_backing modback = none;

	HANDLE handle;

	string processname;
	string dllpath;

	string importing_mod;
	string exporting_mod;
	string exported_fn;

	string mod_to_steal = "";

	vector<string> lines;

	logf(E("DOLBOEB INJECTOR is loading...\n"));

	Start:

	logf(E("waiting for requests\n"));

	try
	{
		WaitForRequest:
			lines = AwaitRequest(ipcfile, 1000);

		RequestArrived:
			logf(E("Request has arrived\n"));
			processname = lines[0];
			if (processname == E("ABORT LMFAO"))
				goto Start;
			dllpath = lines[1];
			importing_mod = lines[2];
			exporting_mod = lines[3];
			exported_fn = lines[4];
			open_process = lines[5] == E("yes");
			create_thread = lines[6] == E("yes");
			wait_10s = lines[8] == E("yes");
			mod_to_steal = lines[9];

			modback = none;

			if (lines[7] == E("create"))
			{
				modback = create_peb_entry;
			}
			if (lines[7] == E("overwrite"))
			{
				modback = overwrite_existing_module;
			}

		WaitForTargetOrTargetHandle:

			if (ReadRequest(ipcfile, lines))
			{
				logf(E("Aborting..\n"));
				goto RequestArrived;
			}
			
			logf(E("waiting for process %s to arrive\n"), processname.c_str());
			Sleep(1000);
			auto process_ids = GetProcessIdsByName(processname);
			if (process_ids.size() == 0) goto WaitForTargetOrTargetHandle;
			auto process_id = process_ids[0];

			logf(E("pr0cess has arr1ved, it's 1D is %d\n"), process_id);

			if (open_process)
			{
				logf(E("opening the handle..\n"));
				handle = OpenProcess(PROCESS_ALL_ACCESS, null, process_id);
			}
			else
			{
				logf(E("searching for handle.. \n"));
				handle = GetProcessHandle(process_id);
			}

			if (handle)
			{
				if (HandleHasAccess(handle, PROCESS_VM_READ | PROCESS_VM_WRITE))
				{
					logf(E("handle: 0x%X, (AccessMask: 0x%X)\n"), handle, QueryHandleAccessMask(handle));
					logf(E("starting 1nj3ction, dll path 1s %s\n"), dllpath.c_str());

					if (modback == overwrite_existing_module)
						logf(E("module backing: will overwrite an existing module %s by mapped image\n"), mod_to_steal.c_str());
					if (modback == create_peb_entry)
						logf(E("module backing: will craft and insert entry into the PEB\n"));
					if (modback == none)
						logf(E("module backing: none\n"));

					if (!create_thread)
						logf(E("thread hjacking configuration: importing module: %s, exporting module: %s, exported function: %s\n"), importing_mod.c_str(), exporting_mod.c_str(), exported_fn.c_str());
					else
						logf(E("no thread hijacking used\n"));

					auto proc = process(handle);
					auto injector = injection::manualmap(proc, modback);
					injector.module_to_hijack = mod_to_steal;

					auto buffer = binary_file::read_file(dllpath);

					bool res;

					if (wait_10s)
						Sleep(10000);

					if(!create_thread)
						res = injector.inject(buffer, true, (char*)importing_mod.c_str(), (char*)exporting_mod.c_str(), (char*)exported_fn.c_str());
					else
						res = injector.inject(buffer);

					logf(res ? E("inj3ction complete\n") : E("injection f7iled\n"));
				}
				else
				{
					logf(E("h7ndle has b3en stripped\n"));
					goto WaitForTargetOrTargetHandle;
				}
			}
			else
			{
				logf(E("couldn't obtain the handle\n"));
				goto WaitForTargetOrTargetHandle;
			}
	}
	catch (exception ex)
	{
		logf(E("fatal exception: %s\n"), ex.what());
		ResetFile(ipcfile);
		Sleep(500);
	}
	goto Start;
}

BOOL WINAPI DllMain(HMODULE hm, DWORD ulCallReason, void*)
{
	static HANDLE hThread;

	if (ulCallReason == DLL_PROCESS_ATTACH)
	{
		hThread = CreateThread(0, 0, main, 0, 0, 0);
	}
	if (ulCallReason == DLL_PROCESS_DETACH)
	{
		logf(E("DOLBOEB.INJECTOR is getting unl0aded, bye\n"));
		TerminateThread(hThread, 0x0);
		CloseHandle(hThread);
		logger::shutdown();
		ExitThread(0);
	}
	return TRUE;
}