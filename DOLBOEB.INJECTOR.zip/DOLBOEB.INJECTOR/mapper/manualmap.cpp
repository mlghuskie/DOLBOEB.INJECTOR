#include "stdafx.h"
#include "memory_section.hpp"
#include "api_set.hpp"

using logger::logf;

uintptr_t injection::manualmap::inject(const std::vector<uint8_t>& buffer, bool bThreadHijack, char* importing_module, char* exporting_module, char* threadhijack_fn)
{
	// GET LINKED MODULES FOR LATER USE
	this->linked_modules = this->process.get_modules();

	if (this->module_backing == overwrite_existing_module)
	{
		module_to_hijack_base = linked_modules[module_to_hijack];
		if (!module_to_hijack_base)
			throw exception(E("couldn't locate module to hijack\n"));
	}

	// INITIALISE CONTEXT
	map_ctx ctx(E("Main Image"), buffer);

	if (bThreadHijack)
	{
		ctx.th_importing_module = importing_module;
		ctx.th_exporting_module = exporting_module;
		ctx.th_fn = threadhijack_fn;
	}

	// MAP MAIN IMAGE AND ALL DEPENDENCIES
	if (!map_image(ctx))
		return 0;

	// CALL MAIN IMAGE ENTRYPOINT

	if (!bThreadHijack)
	{
		if (!call_entrypoint(ctx))
			return 0;
	}
	else
	{
		if (!threadhijack_call_entrypoint(ctx))
			return 0;
	}
	return ctx.remote_image;
}

bool injection::manualmap::map_image(map_ctx& ctx)
{
	auto sz = ctx.pe.get_optional_header().SizeOfImage;
	logf(E("mapping module %s (SizeOfImage: 0x%X)\n"), ctx.image_name.c_str(), sz);

	auto section = memory_section(PAGE_EXECUTE_READWRITE, sz);

	if (!section)
	{
		logger::log_error(E("Failed to create section"));
		return false;
	}

	// MAP SECTION INTO BOTH LOCAL AND REMOTE PROCESS
	ctx.local_image = process::current_process().map(section);
	ctx.remote_image = this->process.map(section);

	if (!ctx.local_image || !ctx.remote_image)
	{
		logger::log_error(E("Failed to map section"));
		return false;
	}

	// ADD MAPPED MODULE TO LIST OF MODULES
	this->mapped_modules.push_back(ctx);

	// MANUALMAP IMAGE
	write_headers(ctx);
	write_image_sections(ctx);
	fix_import_table(ctx);
	relocate_image_by_delta(ctx);

	logf(E("mapped %s at: 0x%X\n"), ctx.image_name.c_str(), ctx.remote_image);

	if (this->module_backing == create_peb_entry)
	{
		//link_to_peb(ctx);
	}

	return true;
}

//void injection::manualmap::link_to_peb(map_ctx& ctx)
//{
//	logf(E("PEB-linking %s\n"), ctx.image_name.c_str());
//
//	auto ldr_data = process.get_loader_data();
//	auto list_base = ldr_data.InLoadOrderModuleList;
//
//	auto pLastEntry = list_base.Blink;
//	auto last_entry = process.read_type<LDR_DATA_TABLE_ENTRY>(pLastEntry);
//	LDR_DATA_TABLE_ENTRY e = last_entry;
//	
//	auto s = last_entry.FullDllName;
//
//	std::wstring wname;
//	wname.resize(s.MaximumLength + 10);
//	wname[s.MaximumLength] = '\n';
//	process.read_raw_memory((void*)wname.c_str(), (uintptr_t)s.Buffer, s.MaximumLength);
//
//	std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
//	string name = converter.to_bytes(wname);
//
//	logf(E("Copying data from entry of %s\n"), name.c_str());
//	
//	e.InLoadOrderLinks.Blink = last_entry.InLoadOrderLinks.Flink;
//	e.DllBase = (void*)ctx.remote_image;
//	e.EntryPoint = 0x0; // not a good idea to set this
//	e.SizeOfImage = ctx.pe.get_optional_header().SizeOfImage;
//
//	auto pEntry = this->process.allocate_and_write(e);
//
//	last_entry.InLoadOrderLinks.Flink = (LIST_ENTRY*)pEntry;
//	this->process.write_memory(last_entry, (uintptr_t)pLastEntry);
//}

uintptr_t injection::manualmap::find_or_map_dependecy(const std::string& image_name)
{
	// HAVE WE MAPPED THIS MODULE ALREADY?
	for (auto module : this->mapped_modules)
		if (module.image_name == image_name)
			return module.remote_image;

	// WAS THIS MODULE ALREADY LOADED BY LDR?
	if (this->linked_modules.find(image_name) != this->linked_modules.end())
		return this->linked_modules.at(image_name);

	// TODO: PROPER FILE SEARCHING
	auto ctx = map_ctx(image_name, binary_file::read_file(E("C:\\Windows\\System32\\") + image_name));

	if (map_image(ctx))
		return ctx.remote_image;

	return 0;
}

void injection::manualmap::write_headers(map_ctx& ctx)
{
	return; // not needed
	memcpy(ctx.local_image_void, ctx.get_pe_buffer(), ctx.pe.get_optional_header().SizeOfHeaders);
}
void injection::manualmap::write_image_sections(map_ctx& ctx)
{
	for (auto section : ctx.pe.get_sections())
		memcpy(reinterpret_cast<void*>(ctx.local_image + section.VirtualAddress), ctx.get_pe_buffer() + section.PointerToRawData, section.SizeOfRawData);
}

bool injection::manualmap::threadhijack_call_entrypoint(map_ctx& ctx)
{
	logf(E("Trying to hijack an existing thread in order to call entrypoint\n"));
	auto imName = ctx.th_importing_module;
	auto pImportingModuleBase = this->linked_modules[imName];
	if (!pImportingModuleBase)
	{
		throw exception(E("C0uldn't find imp0rting module"));
	}
	logf(E("Importing module base address: 0x%X\n"), pImportingModuleBase);
	std::vector<uint8_t> tmpbuff, mmbuff;
	tmpbuff.resize(0x10000); // temporary size
	process.read_raw_memory(tmpbuff.data(), pImportingModuleBase, tmpbuff.size());
	portable_executable tmppe(tmpbuff);
	auto imageSize = tmppe.get_nt_headers()->OptionalHeader.SizeOfImage; // size when mapped in memory lol
	logf(E("Importing module size: 0x%X\n"), imageSize);
	mmbuff.resize(imageSize);
	process.read_raw_memory(mmbuff.data(), pImportingModuleBase, mmbuff.size());
	portable_executable impe(mmbuff);
	auto imports = impe.get_imports((uintptr_t)impe.get_buffer().data());

	// logger::log_imports(imports);

	auto library = imports.find(ctx.th_exporting_module);
	if (library == imports.end()) throw std::exception(E("C0uldn't find the t7rget m0dule."));
	auto libraryImports = library->second;
	import_data imprt;
	bool bFound = false;
	for (auto i : libraryImports)
	{
		if (i.name.find(ctx.th_fn) != std::string::npos)
		{
			logf(E("Found the required function. Name: %s, RVA: 0x%X\n"), i.name.c_str(), i.function_rva);
			bFound = true;
			imprt = i;
			break;
		}
	}
	if (bFound)
	{
		logf(E("Hooking the exported function\n"));

		auto fnPtr = pImportingModuleBase + imprt.function_rva;

		uint64_t originalFn;
		process.read_memory(&originalFn, fnPtr);
		auto optHdr = ctx.pe.get_optional_header();
		uintptr_t base = ctx.remote_image;
		
		if (module_backing == overwrite_existing_module)
			base = module_to_hijack_base;

		uint8_t sc[89] =
		{
			0x51, 0x52, 0x41, 0x50, 0x41, 0x51, 0x48, 0xB9, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC,
			0x48, 0xBA, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0x49, 0xB8, 0xCC, 0xCC, 0xCC, 0xCC,
			0xCC, 0xCC, 0xCC, 0xCC, 0x48, 0x83, 0xEC, 0x28, 0x48, 0xB8, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC,
			0xCC, 0xCC, 0xFF, 0xD0, 0x48, 0x83, 0xC4, 0x28, 0x41, 0x59, 0x41, 0x58, 0x5A, 0x59, 0x53, 0x48,
			0xB8, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC, 0x48, 0xBB, 0xCC, 0xCC, 0xCC, 0xCC, 0xCC,
			0xCC, 0xCC, 0xCC, 0x48, 0x89, 0x03, 0x5B, 0xFF, 0xE0
		};

		*(uintptr_t*)(sc + 8) = base;
		*(uintptr_t*)(sc + 18) = DLL_PROCESS_ATTACH;
		*(uintptr_t*)(sc + 28) = optHdr.SizeOfImage;
		*(uintptr_t*)(sc + 42) = base + optHdr.AddressOfEntryPoint;
		*(uintptr_t*)(sc + 65) = originalFn;
		*(uintptr_t*)(sc + 75) = fnPtr;

		auto pRemoteSc = process.raw_allocate(sizeof(sc));
		process.write_raw_memory(sc, sizeof(sc), pRemoteSc);
		bool b = process.write_memory(pRemoteSc, fnPtr);

		if (!b) throw std::exception(E("C0uldn't overwrite IAT entry"));
		logf(E("Hooked.\n"));

		return true;
	}
	else
	{
		throw std::exception(E("C0uldn't find functi0n in the IAT"));
	}
}

bool injection::manualmap::call_entrypoint(map_ctx& ctx)
{
	// dllmain_call_x64.asm
	uint8_t shellcode[] = { 0x48, 0x83, 0xEC, 0x28, 0x48, 0xB9, 0xCA, 0xCE, 0xCF, 0xCC, 0xCA, 0xCA, 0xCC, 0xCC, 0x48, 0xC7, 0xC2, 0x01, 0x00, 0x00, 0x00, 0x4D, 0x31, 0xC0, 0x48, 0xB8, 0xCC, 0xCA, 0xCC, 0xCC, 0xAA, 0xCA, 0xCC, 0xAA, 0xFF, 0xD0, 0x48, 0x83, 0xC4, 0x28, 0xC3 };

	uintptr_t base = ctx.remote_image;

	if (module_backing == overwrite_existing_module)
		base = module_to_hijack_base;

	*PPTR(shellcode + 0x6) = base;
	*PPTR(shellcode + 0x1A) = base + ctx.pe.get_optional_header().AddressOfEntryPoint;

	auto remote_buffer = this->process.raw_allocate(sizeof(shellcode));

	if (!remote_buffer)
	{
		logger::log_error(E("Failed to allocate shellcode"));
		return false;
	}

	auto success = true;

	do
	{
		if (!this->process.write_raw_memory(shellcode, sizeof(shellcode), remote_buffer))
		{
			logger::log_error(E("Failed to write shellcode"));
			success = false;
			break;
		}

		auto thread_handle = safe_handle(this->process.create_thread(remote_buffer, NULL));

		if (!thread_handle)
		{
			logger::log_error(E("Failed to create shellcode thread"));
			success = false;
			break;
		}

		WaitForSingleObject(thread_handle.get_handle(), INFINITE);
	} while (false);
	

	// FREE SHELLCODE
	this->process.free_memory(remote_buffer);

	return success;
}

void injection::manualmap::relocate_image_by_delta(map_ctx& ctx)
{
	auto delta = ctx.remote_image - ctx.pe.get_image_base();
	bool bDoShift = module_backing == overwrite_existing_module && ctx.image_name == E("Main Image");

	if (bDoShift)
	{
		delta = module_to_hijack_base - ctx.pe.get_image_base();
		logf(E("Doing a shift\n"));
	};

	for (auto&[entry, item] : ctx.pe.get_relocations(ctx.local_image))
		*PPTR(ctx.local_image + entry.page_rva + item.get_offset()) += delta;

	auto sz = ctx.pe.get_optional_header().SizeOfImage;

	if (bDoShift)
	{
		DWORD op;
		VirtualProtectEx(this->process.handle.get_handle(), (void*)module_to_hijack_base, sz, PAGE_EXECUTE_READWRITE, &op);
		process.write_raw_memory((void*)ctx.local_image, sz, module_to_hijack_base);
		logf(E("Nulling out old garbage\n"));
		RtlSecureZeroMemory((void*)ctx.local_image, sz);
		logf(E("Did it\n"));
	}
}

void injection::manualmap::fix_import_table(map_ctx& ctx)
{
	wstring_converter converter;
	api_set api_schema;

	for (auto&[tmp_name, functions] : ctx.pe.get_imports(ctx.local_image))
	{
		auto module_name = tmp_name; // COMPILER COMPLAINED ABOUT tmp_name BEING CONST??

		std::wstring wide_module_name = converter.from_bytes(module_name.c_str());
		if (api_schema.query(wide_module_name))
			module_name = converter.to_bytes(wide_module_name);

		auto module_handle = find_or_map_dependecy(module_name);
		if (!module_handle)
			logger::log_error(E("Failed to map dependency"));

		for (const auto& fn : functions)
		{	
			*PPTR(ctx.local_image + fn.function_rva) = fn.ordinal > 0 ?
				this->process.get_module_export(module_handle, reinterpret_cast<const char*>(fn.ordinal)) :	// IMPORT BY ORDINAL
				this->process.get_module_export(module_handle, fn.name.c_str());							// IMPORT BY NAME
		}
	}
}

uint8_t* map_ctx::get_pe_buffer()
{
	return this->pe.get_buffer().data();
}