#pragma once
#include "stdafx.h"
#include "process.hpp"
#include "portable_executable.hpp"

enum module_backing
{
	none,
	create_peb_entry,
	overwrite_existing_module
};

struct map_ctx
{
	std::string image_name;
	std::string th_importing_module;
	std::string th_exporting_module;
	std::string th_fn;
	portable_executable pe;
	
	union {
		uintptr_t local_image;
		void* local_image_void;

	};
	union {
		uintptr_t remote_image;
		void* remote_image_void;
	};
	
	uint8_t* get_pe_buffer();

	map_ctx() : pe(std::vector<uint8_t>()), remote_image(0) {}
	map_ctx(std::string new_image_name, std::vector<uint8_t> new_buffer) :
		image_name(new_image_name), pe(new_buffer){}
};

using wstring_converter = std::wstring_convert<std::codecvt_utf8<wchar_t>, wchar_t>;
using module_list = std::unordered_map<std::string, uintptr_t>;

namespace injection
{
	class manualmap
	{
	public:
		std::string module_to_hijack;
		manualmap(process& proc, module_backing backing_settings) : process(proc), module_backing(backing_settings) { }
		uintptr_t inject(const std::vector<uint8_t>& buffer, bool bthreadhijack = false, char* importing_module = nullptr, char* exporting_module = nullptr, char* exported_function = nullptr);

	private:
		uintptr_t module_to_hijack_base;
		module_backing module_backing;
		bool map_image(map_ctx& ctx);
		uintptr_t find_or_map_dependecy(const std::string& image_name);
		void write_headers(map_ctx& ctx);
		bool call_entrypoint(map_ctx& ctx);
		bool threadhijack_call_entrypoint(map_ctx& ctx);
		void write_image_sections(map_ctx& ctx);
		void relocate_image_by_delta(map_ctx& ctx);
		void fix_import_table(map_ctx& ctx);
		void link_to_peb(map_ctx& ctx);

		module_list linked_modules;
		std::vector<map_ctx> mapped_modules;
		process& process;
	};
}