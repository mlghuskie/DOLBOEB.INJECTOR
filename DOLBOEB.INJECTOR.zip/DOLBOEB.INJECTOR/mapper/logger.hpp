#pragma once
#include "stdafx.h"
#include "portable_executable.hpp"

using std::string;
using std::exception;

namespace logger
{
	extern HANDLE hLogFile;
	extern string LogFilePath;
	extern string Prefix;
	extern string Postfix;

	inline void initialize(string lf, string prefix, string postfix)
	{
		Postfix = postfix;
		LogFilePath = lf;
		Prefix = prefix;

		hLogFile = CreateFileA
		(
			LogFilePath.c_str(),
			GENERIC_WRITE,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL,
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			NULL
		);
		if (hLogFile == INVALID_HANDLE_VALUE) throw exception(E("Couldn't open log file."));
	}

	inline void shutdown()
	{
		CloseHandle(hLogFile);
	}

	inline void logf(const char* format...)
	{
		char buff[1024];
		va_list va_alist;
		va_start(va_alist, format);
		vsprintf_s(buff, format, va_alist);
		va_end(va_alist);
		string newbuff;
		newbuff = Prefix + buff + Postfix;
		if (!WriteFile(hLogFile, newbuff.c_str(), newbuff.size(), NULL, NULL)) throw exception(E("WriteFile failed"));
	}

	inline void log(const std::string& message)
	{
		logf(E("%s\n"), message.c_str());
	}

	inline void log_error(const std::string& message)
	{
		auto op = Prefix;
		Prefix = E("[!] ");
		logf(E("%s\n"), message.c_str());
		Prefix = op;
	}

	inline void log_imports(import_list imports)
	{
		log_error(E("Dumping imports:\n"));
		for (auto i : imports)
		{
			logf(E("Library: %s\n"), i.first.c_str());
			for (auto imprt : i.second)
			{
				if (imprt.ordinal)
				{
					logf(E(" -  %d -> %s -> 0x%X\n"), imprt.ordinal, imprt.name.c_str(), imprt.function_rva);
				}
				else
				{
					logf(E(" -  %s -> 0x%X\n"), imprt.name.c_str(), imprt.function_rva);
				}
			}
		};
		logf(E("\n"));
	}

	template <class T>
	inline void log_formatted(const std::string& variable_name, const T& variable_data, bool hexadecimal = false)
	{
		logf(E("%s: 0x%X\n"), variable_name.c_str(), variable_data);
	}
}