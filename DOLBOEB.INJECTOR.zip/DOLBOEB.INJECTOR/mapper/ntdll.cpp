#include "stdafx.h"
#include "ntdll.hpp"

fnNtCreateSection ntdll::NtCreateSection = nullptr;
fnNtMapViewOfSection ntdll::NtMapViewOfSection = nullptr;

void ntdll::initialise()
{
	auto module_handle = GetModuleHandleA(E("ntdll.dll"));
	ntdll::NtCreateSection = reinterpret_cast<fnNtCreateSection>(GetProcAddress(module_handle, E("NtCreateSection")));
	ntdll::NtMapViewOfSection = reinterpret_cast<fnNtMapViewOfSection>(GetProcAddress(module_handle, E("NtMapViewOfSection")));

}
