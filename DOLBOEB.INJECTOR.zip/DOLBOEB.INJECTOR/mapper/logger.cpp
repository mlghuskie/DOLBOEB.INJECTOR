#include "stdafx.h"

HANDLE logger::hLogFile;
string logger::Postfix;
string logger::Prefix;
string logger::LogFilePath;
