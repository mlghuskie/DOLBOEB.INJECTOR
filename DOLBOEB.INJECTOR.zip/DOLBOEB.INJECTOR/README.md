# nt-mapper
PE mapper in c++17

# Features
+ Relocate image
+ Update import address table
+ Export directory parsing 

# Todo
+ Static TLS
+ TLS callbacs

# Thanks
+ DarthTon (BlackBone)

